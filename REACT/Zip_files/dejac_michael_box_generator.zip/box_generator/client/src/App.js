import './App.css';
import GenerateBox from './components/GenerateBox';

function App() {
  return (
    <div className="App">
      <GenerateBox/>  
    </div>
  );
}

export default App;
