import React from 'react'

const Navigation = () => {
  return (
    <div id='side-nav'></div>
  )
}

export default Navigation