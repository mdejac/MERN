import React from 'react'

const Header = () => {
  return (
    <div id='header' ></div>
  )
}

export default Header