import React from 'react'

const Advertisement = () => {
  return (
    <div id='advertisement'></div>
  )
}

export default Advertisement