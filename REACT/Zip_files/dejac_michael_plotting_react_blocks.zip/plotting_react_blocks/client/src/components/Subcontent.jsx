import React from 'react'

const Subcontent = () => {
  return (
    <div className='sub-content'></div>
  )
}

export default Subcontent